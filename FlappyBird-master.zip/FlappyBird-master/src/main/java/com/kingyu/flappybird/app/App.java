package com.kingyu.flappybird.app;

/**
 * 游戏入口
 * 
 * @author Kingyu
 *
 */

public class App {
	public static void main(String[] args) {
		new Game();
	}
}
